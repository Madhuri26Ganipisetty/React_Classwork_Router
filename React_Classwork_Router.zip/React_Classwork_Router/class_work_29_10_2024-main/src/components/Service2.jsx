// src/pages/Service1.jsx
const Service1 = () => {
  return (
    <div>
      <h3>Service 2</h3>
      <p>Description of Service 2...</p>
    </div>
  );
};

export default Service1;
